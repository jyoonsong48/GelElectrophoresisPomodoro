@echo off
chcp 949 >nul
echo [1/2] 빌드 시작 (현재 폴더 기준)...

:: main.py가 있는지 먼저 확인
if not exist main.py (
    echo [에러] 이 폴더에 main.py가 없습니다! push.bat 위치를 확인하세요.
    pause
    exit
)

python -m pygbag --build .

echo [2/2] 깃허브 업로드 시도...
:: git이 설치되어 있는지 확인
where git >nul 2>nul
if %errorlevel% neq 0 (
    echo [경고] Git이 설치되지 않았습니다. 빌드된 파일만 수동으로 올리세요.
) else (
    git add .
    git commit -m "update simulator"
    git push origin main
)

echo 업데이트 프로세스 완료!
pause