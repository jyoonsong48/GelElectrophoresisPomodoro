import asyncio
import pygame
import sys
import os
import math
import random
import webbrowser

async def main():
    pygame.init()
    WIDTH, HEIGHT = 500, 375
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Gel Electrophoresis Simulator")
    clock = pygame.time.Clock()

    #images
    def resource_path(relative_path):
        try:

            base_path = sys._MEIPASS
        except Exception:

            base_path = os.path.abspath(".")
        return os.path.join(base_path, relative_path)

    def load_img(name):
        path = path = resource_path(os.path.join("assets", f"{name}.png"))
        return pygame.image.load(path).convert_alpha()

    def load_num_scaled(name, w, h):
        path = path = resource_path(os.path.join("assets", f"{name}.png"))
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.smoothscale(img, (w, h))

    NUM_WIDTH, NUM_HEIGHT = 14, 22
    COLON_WIDTH = 14
    COLON_HEIGHT = 22

    start_img = load_img(f"mainimg")
    laneNloaded_txt = load_img(f"laneNloaded")
    ready_txt = load_img(f"pipetteready")
    pre_time_txt = load_img(f"timeleft")
    time_txt = pygame.transform.scale(pre_time_txt, (350, 375))
    pls_txt = load_img(f"plsload")
    pipetted_txt = load_img(f"pipetted")
    start_image = load_img(f"mainimg")
    Gel_image = load_img(f"GelDefault")
    GelRunning_image = load_img(f"GelOn")
    GelResult_image = load_img(f"GelResult")
    Effendorf_image = load_img(f"E")
    LoadedEffendorf_image = load_img(f"ELoaded")
    Lanes_images = [load_img(f"L{i}") for i in range(0, 6)] # going down (default: lane 0)
    Band_Thick = load_img(f"BandThick")
    Band_Thin = load_img(f"BandThin")
    lid_image = load_img(f"lid")
    pipette_images = [load_img(f"P{i}") for i in range(0, 3)] # 0: w/o tip, 1: w/tip 2: w/tip&loaded
    num_imgs = [load_num_scaled(str(i), NUM_WIDTH, NUM_HEIGHT) for i in range(10)]
    colon_img = load_num_scaled("colon", COLON_WIDTH, COLON_HEIGHT)

    # status
    app_state = "MAIN"
    has_DNA = False
    mouse_x, mouse_y = (0, 0)
    final_x, final_y = (0, 0)
    has_tip = False
    lanes_loaded = [False] * 8
    current_scenario = None
    data_idx = 0
    is_web_opened = False
    current_msg = None
    last_clicked_lane = 0

    LANE_RECTS = [
        pygame.Rect(33, 94, 22, 7),  # Lane 0
        pygame.Rect(66, 94, 22, 7),  # Lane 1
        pygame.Rect(97, 94, 22, 7),  # Lane 2
        pygame.Rect(129, 94, 22, 7), # Lane 3
        pygame.Rect(160, 94, 22, 7), # Lane 4
        pygame.Rect(192, 94, 22, 7), # Lane 5
        pygame.Rect(224, 94, 22, 7), # Lane 6
        pygame.Rect(257, 94, 22, 7)  # Lane 7
    ]
    BASE_X = 33 
    LANE_OFFSETS = [0, 33, 64, 96, 127, 159, 191, 224]
    time_running = 50 * 60 * 1000


    # buttons
    Effendorf_rect = pygame.Rect(378, 167, 33, 88)
    Start_centre = (439, 319)
    Start_radius = 35
    Retry_centre = (435 + 26, 302 + 26)
    Retry_radius = 26
    Des_centre = (435 + 27, 234 + 27)
    Des_radius = 27



    def is_start_clicked(mouse_pos, centre, radius):
        dist = math.sqrt((mouse_pos[0] - centre[0])**2 + (mouse_pos[1] - centre[1])**2)
        return dist <= radius

    def is_retry_clicked(mouse_pos, centre, radius):
        dist = math.sqrt((mouse_pos[0] - centre[0])**2 + (mouse_pos[1] - centre[1])**2)
        return dist <= radius

    def is_desc_clicked(mouse_pos, centre, radius):
        dist = math.sqrt((mouse_pos[0] - centre[0])**2 + (mouse_pos[1] - centre[1])**2)
        return dist <= radius

    def draw_custom_timer(time_str, x, y, spacing=0):
        curr_x = x
        for char in time_str:
            if char == ":":
                screen.blit(colon_img, (curr_x, y))
                curr_x += colon_img.get_width() + spacing
            else:
                img = num_imgs[int(char)]
                screen.blit(img, (curr_x, y))
                curr_x += img.get_width() + spacing

    # scenarios
    scenarios = {
        1: {
            "name": "DNA Ladder",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300]
            ]
        },
        2: {
            "name": "Covid19 Testing",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [185]
            ]
        },
        3: {
            "name": "Find Superbacteria",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [200],
                []
            ]
        },
        4: {
            "name": "Paternity Test",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [140, 240],
                [140, 270],
                [120, 240]
            ]
        },
        5: {
            "name": "Mapping Restriction Enzyme",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [100],
                [170, 260],
                [145, 290],
                [170, 220, 290]
            ]
        },
        6: {
            "name": "Fingerprint Investigation",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [160, 210, 275],
                [150, 210, 290],
                [160, 210, 275],
                [160, 230, 275],
                [180, 250, 305]
            ]
        },
    7: {
            "name": "Investigating Virus Mutation by Time",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [200],
                [205],
                [212],
                [220],
                [235],
                [255]
            ]
        },
        8: {
            "name": "Food Posioning",
            "bands": [
                [110, 130, 155, 185, 220, 255, 285, 300],
                [220],
                [130],
                [185],
                [220],
                [250],
                [280],
                [300]
            ]
        }
    }
    #=================================MAIN LOOP=======================================
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEMOTION:
                (mouse_x, mouse_y) = event.pos
                final_x = mouse_x - 2
                final_y = mouse_y - 315

            if event.type == pygame.MOUSEBUTTONDOWN:
                if app_state == "MAIN":
                    app_state = "IDLE"
                elif app_state == "IDLE":
                    app_state = "LOADING"
                    has_tip = True
                    current_msg = ready_txt
                elif app_state == "LOADING":
                        if Effendorf_rect.collidepoint(event.pos):
                            if has_tip:
                                has_DNA = True
                                current_msg = pipetted_txt
                if has_DNA and app_state == "LOADING":
                    for i in range(8):
                        if LANE_RECTS[i].collidepoint(event.pos):
                            lanes_loaded[i] = True
                            has_DNA = False
                            last_clicked_lane = i
                            current_msg = laneNloaded_txt
                            break


                if is_start_clicked((mouse_x, mouse_y), Start_centre, Start_radius):
                    if app_state == "LOADING":
                        count = lanes_loaded.count(True)
                        if count > 0 and count in scenarios:
                            app_state = "RUNNING"
                            current_scenario = scenarios[count] # [] when update
                            start_ticks = pygame.time.get_ticks()
                            current_msg = time_txt
                        else:
                            current_msg = pls_txt
                
                if is_retry_clicked((mouse_x, mouse_y), Retry_centre, Retry_radius):
                    if app_state == "RESULT":
                        app_state = "IDLE"
                        has_DNA = False
                        has_tip = False
                        lanes_loaded = [False] * 8
                        current_scenario = None
                        data_idx = 0
                        is_web_opened = False
                        current_msg = None
                        last_clicked_lane = 0

                if is_desc_clicked((mouse_x, mouse_y),Des_centre, Des_radius) and app_state == "RESULT":
                    if not is_web_opened:
                        count = lanes_loaded.count(True)
                        webbrowser.open(f"https://github.com/jyoonsong48/Python-Project/tree/main/GelDes/scenario{count}")
                        is_web_opened = True





        screen.fill((255, 255, 255))
        if current_msg != None and current_msg != time_txt:
            screen.blit(current_msg, (0, 0))
        if current_msg == laneNloaded_txt:
            lane = last_clicked_lane
            i = lane
            screen.blit(num_imgs[i+1], (110, 4))

        if app_state == "MAIN":
            screen.blit(start_image, (0,0))
        if app_state == "IDLE":
            screen.blit(Gel_image, (0, 0))
            
        elif app_state == "LOADING":
            screen.blit(Gel_image, (0, 0))
            screen.blit(Effendorf_image, (0, 0))
            screen.blit(LoadedEffendorf_image, (0, 0))
            for i in range(8):
                if lanes_loaded[i]:
                    screen.blit(Lanes_images[0], (LANE_OFFSETS[i], 0))
        elif app_state == "RUNNING":
            screen.blit(GelRunning_image, (0, 0))
            screen.blit(lid_image, (0,0))
            screen.blit(time_txt, (320, 25))
            elapsed = pygame.time.get_ticks() - start_ticks

            remaining = max(0, (time_running - elapsed) // 1000)
            time_str = f"{remaining//60:02}:{remaining%60:02}"
            draw_custom_timer(time_str, 370, 81, spacing= +3)

            img_idx = int((elapsed / time_running) * 6)
            if img_idx > 5: img_idx = 5 
            for i in range(8):
                if lanes_loaded[i]:
                    screen.blit(Lanes_images[img_idx], (LANE_OFFSETS[i], 0))
            if elapsed >= time_running:
                        app_state = "RESULT"
                        if app_state == "RESULT":
                            screen.fill((255, 0, 255))
                            pygame.display.flip()
                            pygame.time.delay(200)
                            screen.blit(GelResult_image, (0, 0))
                            pygame.display.flip()
                            pygame.time.delay(200)
                            screen.fill((255, 0, 255))
                            pygame.display.flip()
            
                        
        elif app_state == "RESULT":
            screen.blit(GelResult_image, (0, 0))
            current_data_idx = 0
            if True in lanes_loaded:
                first_lane = lanes_loaded.index(True)
                for i in range(8):
                    if lanes_loaded[i]:
                        if i == first_lane:
                            y_list = current_scenario["bands"][current_data_idx]
                            for y in y_list:
                                screen.blit(Band_Thick, (LANE_OFFSETS[i] + 33, y))
                        else:
                            y_list = current_scenario["bands"][current_data_idx]
                            for y in y_list:
                                screen.blit(Band_Thin, (LANE_OFFSETS[i] + 33, y))
                        current_data_idx += 1
        
        if has_tip:
            screen.blit(pipette_images[1], (final_x, final_y))
        if has_DNA:
            screen.blit(pipette_images[2], (final_x, final_y))
        
        
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())